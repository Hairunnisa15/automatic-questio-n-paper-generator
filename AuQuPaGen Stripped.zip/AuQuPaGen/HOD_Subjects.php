<?php
include('dbConnection.php');
include('Header_HOD.html');
$course = $_REQUEST['courseName'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $course ?></title>


    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>

    <center>

        <div>
            <h2 style="background-color: wheat; color: while;">View Course</h2>
        </div>
        <table border="2" class="customers">
            <tr>
                <th>Subject</th>
                <th>CREATED On</th>
                <br />
                <br />
                <br />
            </tr>

            <?php

            $res = mysqli_query($mycon, "SELECT * FROM `tb_subject`  WHERE `course_name`='$course'");

            // echo "SELECT * FROM `tb_course` c WHERE c.`course_name`='$course'";

            $cou = $course;
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr><td>$rs[subj_name]</td><td>$rs[cretaed_on]</td></tr>";
            }
            ?>
        </table>
        <br>
        <br>


        <div>
            <h2 style="background-color: wheat; color: while;">Add Subject</h2>
        </div>

        <div class="col-md-6">
            <form method="POST">
                <br>
                <br>
                <br>
                <input class="form-control" type="text" placeholder="Subject Name" name="subj_name"><br><br>
                <!-- <select name="deptname">
                <option>....Choose Department....</option>
               
            </select><br><br> -->


                <!-- <input type="submit" value="Add Subject" name="add_btn"> -->

                <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="submit" value="Add Exam" name="add_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add Subject</button>
                    </div>
                </div>

            </form>

            <br>
            <br>
            <br>
        </div>
    </center>


</body>

</html>


<?php





if (isset($_REQUEST['add_btn'])) {

    $subj_name = $_REQUEST['subj_name'];
    $date = date("d/m/Y");

    $chk_qry = "SELECT count(*) as cnt FROM `tb_subject`  WHERE `subj_name`='$subj_name'";

    // echo $chk_qry;
    $qry = "insert into  `tb_subject`  ( `subj_name`,`course_name`,`cretaed_on`) values ('$subj_name','$cou','$date')";

    // echo $qry;

    $res = mysqli_query($mycon, $chk_qry);

    $rs = mysqli_fetch_array($res);

    if ($rs['cnt'] > 0) {
        echo "<script>alert('Subject Already Exist !')</script>";
        echo "<script>window.location.href='HOD_Subjects.php?courseName=$cou';</script>";
    } else {
        mysqli_query($mycon, $qry);
        echo "<script>alert('Added New Subject')</script>";
        echo "<script>window.location.href='HOD_Subjects.php?courseName=$cou';</script>";
    }
}

?>


<?php
include('MainFooter.html');
?>