<?php
session_start();
include("dbConnection.php");
include("MainBanner.html");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>

    <!-- //Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Font-Awesome-Icons-CSS -->
    <!-- //Custom-Files -->

    <!-- Web-Fonts -->
    <link href="//fonts.googleapis.com/css?family=Sarabun:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Crimson+Text:400,400i,600,600i,700,700i" rel="stylesheet">
    <!-- //Web-Fonts -->

</head>


<body>
    <center>



        <div class="col-lg-6 mt-lg-0 mt-5" data-aos="zoom-in">
            <!-- form grid -->
            <div class="register-top1">
                <form method="POST" class="register-wthree" action="process_login.php">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                                <label>
                                    User name
                                </label>
                                <input class="form-control" type="text" placeholder="username" name="name" required="">
                            </div>

                            <br>

                            <div class="col-md-6 mt-md-0 mt-4">
                                <label>
                                    Password
                                </label>
                                <input class="form-control" type="password" placeholder="password" name="pass" required="">
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-12">
                                <input type="submit" name="login_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">
                            </div>
                        </div>
                </form>
            </div>
        </div>
        <!--  //form grid ends here -->
    </center>
</body>


</html>
<?php
include("mainfooter.html")
?>