<?php
session_start();
include('Header_Admin.html');
include('dbConnection.php');
// Store the file name into variable 
if (!empty($_GET['filename'])) {
    $_SESSION['file'] = $_GET['filename'];
    $_SESSION['examid'] = $_GET['examid'];
}




?>
<center style="background-color: white; padding-top: 50px;padding-bottom: 50px;">


    <form method="POST">
        <input name="btn_rej" type="submit" value="Reject Q Paper" style="background-color: red;color: white; font-size: 30px;">
        <input name="btn_appr" type="submit" value="Approve Q Paper" style="background-color: green;color: white; font-size: 30px;">

    </form>
    <br>
    <br>
    <br>
    <iframe src="QP_Bank/<?php echo $_SESSION['file']  ?>" width="90%" style="height:1000px"></iframe>

    <br>
    <br>
    <br>
</center>

<?php
if (isset($_POST['btn_rej'])) {


    $rej_qry = "UPDATE `tb_examdate` SET `status` ='declined' WHERE `exam_id`=" . $_SESSION['examid'] . "";
    if (mysqli_query($mycon, $rej_qry)) {

        echo "<script>alert('Rejected Paper   " . $_SESSION["file"] . "')</script>";
        echo "<script>window.location.href='Admin_exam.php'</script>";
    } else {
        echo "<script>alert('Failed to Reject')</script>";
    }
}

if (isset($_POST['btn_appr'])) {


    $app_qry = "UPDATE `tb_examdate` SET `status` ='approved' WHERE `exam_id`=" . $_SESSION['examid'] . "";
    if (mysqli_query($mycon, $app_qry)) {

        echo "<script>alert('Accepted Paper   " . $_SESSION["file"] . "')</script>";
        echo "<script>window.location.href='Admin_exam.php'</script>";
    } else {
        echo "<script>alert('Failed to Accept')</script>";
    }
}

include('MainFooter.html');

?>