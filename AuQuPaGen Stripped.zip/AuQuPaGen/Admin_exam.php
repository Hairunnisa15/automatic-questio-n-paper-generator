<?php
include('dbConnection.php');
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    function funGetCourse(dept_name) {
        // alert(id);
        $('#Locality').load("CourseAJAX.php?deptName=" + dept_name);
    };

    // function funGetSubj(course_name) {
    //     debugger;
    //     // alert(id);
    //     $('#Locality2').load("SubjectAJAX.php?courseName=" + course_name);
    // };
</script>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examinations</title>
    <?php
    include('Header_Admin.html');
    ?>

    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>

    <center>
        <div>
            <h2 style="background-color: wheat; color: while;">Add Exam</h2>
        </div>

        <div class="col-md-6">
            <form>
                <br>
                <br>
                <br>
                <input class="form-control" type="text" placeholder="Exam Name" name="exam_name" required>
                <br><br>
                <label for="ExamDate">Exam Date:</label>
                <input class="form-control" type="date" id="ExamDate" name="exam_date" required>
                <br><br>
                <?php

                $query = mysqli_query($mycon, "SELECT * from `tb_department`"); // Run your query
                echo '<select name="District" onchange="funGetCourse(this.value)" class="form-control">'; // Open your drop down box
                echo '<option>Select Department</option>';
                // Loop through the query results, outputing the options one by one
                while ($row = mysqli_fetch_assoc($query)) {

                    echo '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
                }
                echo '</select>'; // Close your drop down box



                ?>
                <br>
                <br>
                <div id="chooselocality">
                    <select name="Locality" id="Locality" onchange="myfunction()" class="form-control">


                    </select>
                </div>
                <br>
                <br>

                <div id="chooselocality2">

                    <select name="Locality2" id="Locality2" class="form-control">
                    </select>

                </div>


                <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="submit" value="Add Exam" name="addcourse_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add Exam</button>
                    </div>
                </div>

            </form>
        </div>
    </center>
    <script>
        function myfunction() {
            // debugger;
            var data = $("#Locality").val()
            // alert(data);
            $.ajax({

                url: "SubjectAJAX.php",
                method: "POST",
                data: {
                    selected: data
                },
                success: function(data) {
                    // alert(data);
                    $('#Locality2').html(data);
                    $('#Locality2').multiselect('rebuild');
                }
            })
        };
    </script>


    <center>
        <div>
            <h2 style="background-color:cornflowerblue; color: white;">All Examinations</h2>
        </div>
        <table border="1" class="customers">
            <tr>
                <th>Exam Name</th>
                <th>Department</th>
                <th>Course</th>
                <th>Subject</th>
                <th>Date of Exam</th>
                <th style="padding: 30px;">Q Paper</th>
                <th>Question Paper</th>
                <th>Status</th>

            </tr>
            <?php
            $res = mysqli_query($mycon, "  select * from `tb_examdate` ");
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr>
                <td>$rs[exam_name]</td>
                <td>$rs[department]</td>
                <td>$rs[course]</td>
                <td>$rs[subject]</td>
                <td>$rs[exam_date]</td>
                <td>$rs[qp_file]</td>
                <td><a href='Admin_View_paper.php?filename=$rs[qp_file]&examid=$rs[exam_id]'>View</a></td>
                <td>$rs[status]</td>
                </tr>";
            }
            ?>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
    </center>

</body>

</html>

<?php

if (isset($_GET["addcourse_btn"])) {

    $dept_Name = $_GET["District"];
    $course_Name = $_GET["Locality"];
    $subj_Name = $_GET["Locality2"];
    $Exam_Name = $_REQUEST["exam_name"];
    $Exam_Date = $_REQUEST["exam_date"];


    if ($dept_Name == 'Select Department') {
        echo "<script>alert('Choose Department')</script>";
        // echo "<script>window.location.href='Admin_exam.php'</script>";
    } else  if ($course_Name == 'Select Course') {
        echo "<script>alert('Choose Course')</script>";
        // echo "<script>window.location.href='Admin_exam.php'</script>";
    } else  if ($subj_Name == 'Select Subject') {
        echo "<script>alert('Choose Subject')</script>";
        // echo "<script>window.location.href='Admin_exam.php'</script>";
    } else {
        // echo "<br><br>Succes";

        $ins_exam_qry = "INSERT INTO `tb_examdate` (`exam_name`,`exam_date`,`department`,`course`,`subject`)
        VALUES('$Exam_Name','$Exam_Date','$dept_Name','$course_Name','$subj_Name')";

        // echo $ins_exam_qry;

        $res = mysqli_query($mycon, $ins_exam_qry);

        if (!$res) {
            // an error eoccurred
            echo "<script>alert('Error in Adding Exam')</script>";
        } else {
            echo "<script>alert('Added Exam')</script>";
            echo "<script>window.location.href='Admin_exam.php'</script>";
        }
    }
}

?>
<?php
include("mainfooter.html")
?>