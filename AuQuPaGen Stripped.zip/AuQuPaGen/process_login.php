<?php
include("dbConnection.php");
session_start();
// if (isset($_REQUEST['login_btn'])) {

$username = $_REQUEST['name'];
$pass = $_REQUEST['pass'];
$qry = "SELECT count(*) as cnt, username, regid, usertype FROM `tb_login` WHERE `username`='$username' AND `password`='$pass'";

echo $qry;

$res = mysqli_query($mycon, $qry);
$rs = mysqli_fetch_array($res);



// if user exist 

if ($rs['cnt'] > 0 &&  $rs['usertype'] == 'ADMIN') {

    $_SESSION['adminid'] = $rs['regid'];

    // Redirect to Login Page
    echo "<script>alert('Succesfully Loged in !')</script>";
    echo "<script>window.location.href='AdminHome.php'</script>";
} else if ($rs['cnt'] > 0 &&  $rs['usertype'] == 'HOD') {


    $_SESSION['hod_name'] = $rs['username'];


    // Redirect to Login Page
    echo "<script>alert('Succesfully Loged in !')</script>";
    echo "<script>window.location.href='HODHome.php'</script>";
} else if ($rs['cnt'] > 0 &&  $rs['usertype'] == 'TEACHER') {


    $_SESSION['teachName'] = $rs['username'];

    // Redirect to Login Page
    echo "<script>alert('Succesfully Loged in !')</script>";
    echo "<script>window.location.href='TeacherHome.php'</script>";
} else {

    echo "<script>alert('Login Failed\n')</script>";
    echo "<script>window.location.href='Login.php'</script>";
    // echo $qry;
}
// }
