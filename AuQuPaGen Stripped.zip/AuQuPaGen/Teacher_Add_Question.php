<html>

<head>
    <title>Add Question</title>
</head>


<?php
session_start();
include('Header_Teacher.html');
include('dbConnection.php');


$tech_name = $_SESSION['teachName'];

$res = mysqli_query($mycon, "SELECT * FROM `tb_teacher` WHERE `name`='$tech_name'");
$rs = mysqli_fetch_array($res);

$Dept = $rs['dept_name'];
$Course = $rs['course_name'];
// echo $Dept . $Course;
?>

<body>
    <center>
        <div class="col-md-6">
            <form>
                <br>
                <br>
                <select class="form-control" name="subj">
                    <option>Choose Subject</option>
                    <?php
                    $res = mysqli_query($mycon, "SELECT * from `tb_subject` WHERE `course_name`='$Course' ");
                    while ($rs = mysqli_fetch_array($res)) {
                        echo "<option >" . $rs['subj_name'] . "</option>";
                    }
                    ?>
                </select>
                <br>
                <br>
                <br><select class="form-control" name="q_type">
                    <option>Choose Type</option>
                    <?php
                    $res = mysqli_query($mycon, "SELECT * from `tb_ques_type`");
                    while ($rs = mysqli_fetch_array($res)) {
                        echo "<option >" . $rs['model_name'] . "</option>";
                    }
                    ?>
                </select>
                <br><br>
                <textarea class="form-control" style="width: 400px;height: 100px;" placeholder="Question" name="question" required></textarea><br><br>
                <textarea class="form-control" style="width: 400px;height: 200px;" placeholder="Answer" name="answer" required></textarea><br><br>


                <!-- <input type="submit" value="Add Question" name="addq_btn"> -->

                <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="submit" name="addq_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add Question</button>
                    </div>
                </div>
            </form>
            <br>
            <br> <br>
            <br>
        </div>
    </center>
</body>

</html>
<?php
if (isset($_REQUEST['addq_btn'])) {

    $question = $_REQUEST['question'];
    $answer = $_REQUEST['answer'];
    $type = $_REQUEST['q_type'];
    $subj = $_REQUEST['subj'];
    $date = date("d/m/Y");

    $qry = "INSERT INTO `tb_q_bank`(`depart_name`,`course_name`,`subject_name`,`teacher_id`,`q_type`,`Question`,`answer`,`created_on`,`status`)
     VALUES  ('$Dept','$Course','$subj','$tech_name','$type','$question','$answer','$date','pending')";

    // echo $qry;

    if ($subj == "Choose Subject") {
        echo "<script>alert('Choose Subject')</script>";
    } else if ($type == "Choose Type") {
        echo "<script>alert('Choose Type')</script>";
    } else {
        mysqli_query($mycon, $qry);
        echo "<script>alert('Added New Question')</script>";
        echo "<script>window.location.href='Teacher_Add_Question.php';</script>";
    }
}

?>

<?php
include('MainFooter.html');
?>