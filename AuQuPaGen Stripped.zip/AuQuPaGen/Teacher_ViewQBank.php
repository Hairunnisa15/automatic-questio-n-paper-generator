<?php
session_start();
include('Header_Teacher.html');
include('dbConnection.php');


$tech_name = $_SESSION['teachName'];

$res = mysqli_query($mycon, "SELECT * FROM `tb_teacher` WHERE `name`='$tech_name'");
$rs = mysqli_fetch_array($res);

$Dept = $rs['dept_name'];
$Course = $rs['course_name'];
// echo $Dept . $Course;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $Dept . " Department-" ?> Q Bank</title>

    <style>
        #gapp {
            padding: 8px;
        }





        <style>.customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
    </style>
</head>

<body>
    <center>
        <table border="1" class="customers">
            <tr>
                <th>Subject Name</th>
                <th>Course</th>
                <th>Q Type</th>
                <th>Question</th>
                <th>Answer</th>
                <th>Created On</th>
                <th>created By</th>
                <br />
                <br />
                <br />
            </tr>
            <?php
            $res = mysqli_query($mycon, "SELECT * FROM `tb_q_bank` WHERE  `course_name`='$Course' ORDER by `subject_name` ");
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr>
                <td>$rs[subject_name]</td>
                <td>$rs[course_name]</td>
                <td>$rs[q_type]</td>
                <td id='gapp'>$rs[Question]</td>
                <td id='gapp'>$rs[answer]</td>
                <td>$rs[created_on]</td>
                <td>$rs[teacher_id]</td>
                </tr>";
            }
            ?>
        </table>
    </center>




</body>

</html>

<?php
include('MainFooter.html');
?>