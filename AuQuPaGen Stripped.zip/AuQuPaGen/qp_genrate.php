<?php
include('dbConnection.php');
include('Header_HOD.html');


$examID = $_GET['exam_id'];
$courseName = $_GET['courseN'];
$subjectName = $_GET['subjectN'];
$examName = $_GET['examN'];
$examDate = $_GET['examD'];
// echo $examID;


// Getting Count of available Question from DB

$getPart_A = "SELECT COUNT(*) as cnt FROM `tb_q_bank` WHERE  `q_type`='Part a' AND `course_name`='$courseName' AND `subject_name`='$subjectName'";
$getPart_B = "SELECT COUNT(*) as cnt FROM `tb_q_bank` WHERE  `q_type`='Part b' AND `course_name`='$courseName' AND `subject_name`='$subjectName'";
$getPart_C = "SELECT COUNT(*) as cnt FROM `tb_q_bank` WHERE  `q_type`='Part c' AND `course_name`='$courseName' AND `subject_name`='$subjectName'";

// echo $getPart_A;
// echo $getPart_B;
// echo $getPart_C;

$responseA = mysqli_query($mycon, $getPart_A);
$responseB = mysqli_query($mycon, $getPart_B);
$responseC = mysqli_query($mycon, $getPart_C);

$arrvalA = mysqli_fetch_array($responseA);
$arrvalB = mysqli_fetch_array($responseB);
$arrvalC = mysqli_fetch_array($responseC);

$getPart_Acount = $arrvalA['cnt'];
$getPart_Bcount = $arrvalB['cnt'];
$getPart_Ccount = $arrvalC['cnt'];

// echo $getPart_Acount . "<br>";

// echo (rand(1, $getPart_Acount));

?>
<!-- ................................................................................................................................................. -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "$examName" ?></title>

    <style>
        .bodyman {
            padding: 20px;
            border-style: dotted;
            border-width: 3px;
            /* border-left-width: 10px; */
            /* border-right-width: 10px; */
            border-color: black;
        }
    </style>



    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>

    <style type="text/css" media="print">
        @page {
            size: auto;
            /* auto is the initial value */
            margin: 4mm;
            margin-top: 10mm;
            margin-bottom: 10mm;
            /* this affects the margin in the printer settings */
        }

        html {
            background-color: #FFFFFF;
            margin: 0px;
            /* this affects the margin on the html before sending to printer */
        }
    </style>




</head>

<body>
    <button onclick="printDiv('printableArea')" style="text-align: center; background-color: crimson;color: white; padding: 8px;">Save this Question Paper</button>
    <button onClick="window.location.reload();" style="text-align: center; background-color: goldenrod;color: white; padding: 8px;">Regenerate Set</button>

    <br>
    <br>
    <br>

    <div id="printableArea" class="bodyman">


        <form>
            <center>
                <div>
                    <h1><?php echo "$examName" ?></h1>
                    <h4>University Board Examination 2020</h4>
                    <br>
                    <h4><?php echo "$courseName" ?></h4>
                    <h4><?php echo "$subjectName" ?></h4>
                    <h4 style="text-align:right ;"> Max Time : 2 hrs</h4>
                    <h4 style="text-align:right ;">Date : <?php echo "$examDate" ?></h4>
                    <br>
                    <br>
                </div>
                ..........................................................................................................................................
                <h2>Section A</h2><br>
                <h4 style="text-align:right ;">2 Marks Each</h4>
                <br>

            </center>

            <div style="padding-left: 100px;">
                <?php

                for ($count = 1; $count <= 10; $count++) {

                    $randPartA = "SELECT * FROM `tb_q_bank` WHERE `q_type`='Part a' AND `course_name`='$courseName' AND `subject_name`='$subjectName' ORDER BY RAND() LIMIT 1";
                    $responseRandA = mysqli_query($mycon, $randPartA);
                    $arrvalrandA = mysqli_fetch_array($responseRandA);



                    echo "Q" . $count . ".       $arrvalrandA[Question]" . "<br><br>";
                }

                ?>
            </div>
            <center>
                <h2>Section B</h2><br>
                <h4 style="text-align:right ;">5 Marks Each</h4>
                <br>

            </center>

            <div style="padding-left: 100px;">


                <?php

                for ($count = 1; $count <= 5; $count++) {

                    $randPartA = "SELECT * FROM `tb_q_bank` WHERE `q_type`='Part b' AND `course_name`='$courseName' AND `subject_name`='$subjectName' ORDER BY RAND() LIMIT 1";
                    $responseRandA = mysqli_query($mycon, $randPartA);
                    $arrvalrandA = mysqli_fetch_array($responseRandA);



                    echo "Q" . $count . ".     $arrvalrandA[Question]" . "<br><br>";
                }

                ?>

            </div>

            <center>
                <h2>Section C</h2><br>
                <h4 style="text-align:right ;">10 Marks Each</h4>
                <br>

            </center>

            <div style="padding-left: 100px;">
                <?php

                for ($count = 1; $count <= 3; $count++) {

                    $randPartA = "SELECT * FROM `tb_q_bank` WHERE `q_type`='Part c' AND `course_name`='$courseName' AND `subject_name`='$subjectName' ORDER BY RAND() LIMIT 1";
                    $responseRandA = mysqli_query($mycon, $randPartA);
                    $arrvalrandA = mysqli_fetch_array($responseRandA);



                    echo "Q" . $count . ".      $arrvalrandA[Question]" . "<br><br>";
                }

                ?>
            </div>

        </form>


    </div>
</body>

</html>