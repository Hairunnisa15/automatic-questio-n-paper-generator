<html>
<?php
include('dbConnection.php');
$dist_id = $_REQUEST['deptName'];
// echo"<script>alert(".$dist_id.")</script>";
?>
<?php

$que = "SELECT * FROM `tb_course` WHERE `department`='$dist_id'";

$query = mysqli_query($mycon, $que); // Run your query
// echo '<select name="Locality" >'; // Open your drop down box
echo '<option>Select Course</option>';
// Loop through the query results, outputing the options one by one
while ($row = mysqli_fetch_assoc($query)) {

    echo '<option value="' . $row['coursename'] . '">' . $row['coursename'] . '</option>';
}
// echo "</select>"; // Close your drop down box

?>


</html>