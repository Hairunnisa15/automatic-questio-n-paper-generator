<?php
include('dbConnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD HOD</title>
</head>

<body>

    <?php
    include('Header_Admin.html');
    ?>

    <center>
        <div class="col-md-6">

            <form>
                <br>
                <br>
                <br>
                <input class="form-control" type="text" placeholder="HOD name" name="hod_name"><br><br>
                <input class="form-control" type="text" placeholder="Email" name="hod_email"><br><br>
                <input class="form-control" type="text" placeholder="Contact" name="hod_mob"><br><br>
                <input class="form-control" type="text" placeholder="Password" name="hod_pass"><br><br>
                <select class="form-control" name="deptname">
                    <option>....Choose DEPARTMENT....</option>
                    <?php
                    $res = mysqli_query($mycon, "SELECT * from `tb_department`");
                    while ($rs = mysqli_fetch_array($res)) {
                        echo "<option >" . $rs['name'] . "</option>";
                    }
                    ?>
                </select><br><br>

                <br>
                <br>
                <!-- <input type="submit" value="Add HOD" name="add_btn"> -->
                <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="submit" value="Add Exam" name="add_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add HOD</button>
                    </div>
                </div>

            </form>
        </div>
    </center>

</body>

</html>
<?php
if (isset($_REQUEST['add_btn'])) {

    $email = $_REQUEST['hod_email'];
    $contact = $_REQUEST['hod_mob'];
    $name = $_REQUEST['hod_name'];
    $department = $_REQUEST['deptname'];
    $pass = $_REQUEST['hod_pass'];

    $date = date("d/m/Y");


    $qry = "INSERT INTO `tb_hod` (`name`,`contact`,`email_id`,`depart_name`,`created_on`) 
    VALUES('$name','$contact','$email','$department','$date')";

    $qry2 = "INSERT INTO `tb_login` (`regid`,`usertype`,`username`,`password`) VALUES('select max(`hod_ID`) from `tb_hod`','HOD','$name','$pass')";

    // echo $qry;

    $res = mysqli_query($mycon, "SELECT COUNT(*) AS cnt FROM `tb_login` WHERE `username`='$name' AND `usertype`='HOD'");
    $res2 = mysqli_query($mycon, "SELECT COUNT(*) AS cnt FROM `tb_hod` WHERE `depart_name`='$department'");

    $rs = mysqli_fetch_array($res);
    $rs2 = mysqli_fetch_array($res2);

    if ($rs['cnt'] > 0 || $rs2['cnt'] > 0) {
        echo "<script>alert('HOD Already Assigned')</script>";
        echo "<script>window.location.href='Admin_AddHOD.php';</script>";
    } else {
        mysqli_query($mycon, $qry);
        mysqli_query($mycon, $qry2);
        echo "<script>alert('Added New HOD')</script>";
        echo "<script>window.location.href='AdminHome.php';</script>";
    }
}
?><?php
    include("mainfooter.html")
    ?>