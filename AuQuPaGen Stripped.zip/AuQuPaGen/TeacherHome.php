<html>


<?php
include('Header_Teacher.html');
?>

</html>

<?php
include('MainFooter.html');
?>