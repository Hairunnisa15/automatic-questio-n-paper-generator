
<?php
include('dbConnection.php');
//$courseName = $_REQUEST['courseName'];
if (isset($_POST["selected"]))
    $courseName = $_POST["selected"];
// echo "<script>alert(" . $dist_id . ")</script>";
?>
<?php
$que = "SELECT * FROM `tb_subject` WHERE `course_name`='$courseName'";
// echo $que;
$query = mysqli_query($mycon, $que); // Run your query
// echo '<select name="Locality" >'; // Open your drop down box
echo '<option>Select Subject</option>';
// Loop through the query results, outputing the options one by one
while ($row = mysqli_fetch_assoc($query)) {

    echo '<option value="' . $row['subj_name'] . '">' . $row['subj_name'] . '</option>';
}
// echo '</select>'; // Close your drop down box

?>


