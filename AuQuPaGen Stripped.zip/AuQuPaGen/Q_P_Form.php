<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Q Paper Form</title>

    <style>
        #bodyman {
            padding: 20px;
            border-style: dotted;
            border-width: 3px;
            /* border-left-width: 10px; */
            /* border-right-width: 10px; */
            border-color: black;
        }
    </style>

</head>

<body id="bodyman">

    <center>

        <form>
            <div>
                <h1>Name Of Examination</h1>
                <h4>University Board Examination 2020</h4>
                <h4 style="text-align:right ;"> Max Time : 2 hrs</h4>
                <h4 style="text-align:right ;">Date :</h4>
                <br>
                <br>
            </div>

            <h2>Section A</h2><br>

            Q1.
            <br>
            Q2.
            <br>
            Q3.
            <br>
            Q4.
            <br>
            Q5.
            <br>
            Q6.
            <br>
            Q7.
            <br>
            Q8.
            <br>
            Q9.
            <br>
            Q10.
            <br>




            <h2>Section B</h2><br>
            Q1.
            <br>
            Q2.
            <br>
            Q3.
            <br>
            Q4.
            <br>
            Q5.
            <br>
            <h2>Section C</h2><br>
            Q1.
            <br>
            Q2.
            <br>

        </form>

    </center>

</body>

</html>