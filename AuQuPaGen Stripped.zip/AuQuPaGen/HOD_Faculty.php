<?php
session_start();
include('dbConnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Faculty</title>
    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>

    <?php
    include('Header_HOD.html');

    $hodname = $_SESSION['hod_name'];
    $get_detail = "select * from `tb_hod` where `name`='$hodname'";

    $res = mysqli_query($mycon, $get_detail);
    $rs = mysqli_fetch_array($res);

    $deptname = $rs['depart_name'];


    ?>

    <center>
        <div class="col-md-6">
            <form>
                <br>
                <br>
                <br>
                <input class="form-control" type="text" placeholder="Teacher Name" name="hod_name"><br><br>
                <input class="form-control" type="text" placeholder="Email" name="hod_email"><br><br>
                <input class="form-control" type="text" placeholder="Contact" name="hod_mob"><br><br>
                <input class="form-control" type="text" placeholder="Password" name="hod_pass"><br><br>
                <select class="form-control" name="coursename">
                    <option>....Choose Course....</option>
                    <?php
                    $res = mysqli_query($mycon, "SELECT * from `tb_course` where `department`='$deptname'");
                    while ($rs = mysqli_fetch_array($res)) {
                        echo "<option >" . $rs['coursename'] . "</option>";
                    }
                    ?>
                </select><br><br>


                <!-- <input type="submit" value="Add Teacher" name="add_btn"> -->
                <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="submit" value="Add Exam" name="add_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add Teacher</button>
                    </div>
                </div>

            </form>

            <br>
            <br>
            <br>
        </div>

        <div>
            <h2 style="background-color: wheat; color: while;">View Faculty</h2>
        </div>
        <table border="1" class="customers">
            <tr>
                <th>Department</th>
                <th>Course</th>
                <th>Teacher</th>
                <th>CREATED On</th>
                <th>Subjects</th>

                <br />
                <br />
                <br />
            </tr>
            <?php

            $hodname = $_SESSION['hod_name'];

            $selqry = "SELECT *,c.`name` as tname FROM `tb_teacher` c, `tb_department`h WHERE c.`dept_name`=h.`name`  AND c.`dept_name`='$deptname'";
            $res = mysqli_query($mycon, $selqry);

            // echo $selqry;
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr><td>$rs[dept_name]</td><td>$rs[course_name]</td><td>$rs[tname]</td><td>$rs[created_on]</td></tr>";
            }
            ?>
        </table>
        <br>
        <br>




    </center>

</body>

</html>
<?php
if (isset($_REQUEST['add_btn'])) {

    $email = $_REQUEST['hod_email'];
    $contact = $_REQUEST['hod_mob'];
    $name = $_REQUEST['hod_name'];
    $courseName = $_REQUEST['coursename'];
    $pass = $_REQUEST['hod_pass'];

    $date = date("d/m/Y");


    $qry = "INSERT INTO `tb_teacher` (`name`,`contact`,`email`,`course_name`,`dept_name`,`created_on`) 
    VALUES('$name','$contact','$email','$courseName','$deptname','$date')";

    $qry2 = "INSERT INTO `tb_login` (`regid`,`usertype`,`username`,`password`) VALUES('select max(`teach_id`) from `tb_teacher`','TEACHER','$name','$pass')";

    // echo $qry;

    $res = mysqli_query($mycon, "SELECT COUNT(*) AS cnt FROM `tb_login` WHERE `username`='$name' AND `usertype`='TEACHER'");
    $res2 = mysqli_query($mycon, "SELECT COUNT(*) AS cnt FROM `tb_teacher` WHERE `course_name`='$courseName'");

    echo "SELECT COUNT(*) AS cnt FROM `tb_teacher` WHERE `course_name`='$courseName'";


    $rs = mysqli_fetch_array($res);
    $rs2 = mysqli_fetch_array($res2);

    if ($rs['cnt'] > 0 || $rs2['cnt'] > 0) {
        echo "<script>alert('Teacher Already EXIST')</script>";
        echo "<script>window.location.href='HOD_Faculty.php';</script>";
    } else {
        mysqli_query($mycon, $qry);
        mysqli_query($mycon, $qry2);
        echo "<script>alert('Added New Teacher')</script>";
        echo "<script>window.location.href='HOD_Faculty.php';</script>";
    }
}
?>

<?php
include('MainFooter.html');
?>