<?php
session_start();
include('dbConnection.php');
include('Header_HOD.html');


$hodname = $_SESSION['hod_name'];
$get_detail = "select * from `tb_hod` where `name`='$hodname'";

$res = mysqli_query($mycon, $get_detail);
$rs = mysqli_fetch_array($res);

$deptname = $rs['depart_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examinations</title>

    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>


    <center>
        <div>
            <h2 style="background-color:cornflowerblue; color: white;">Examinations</h2>
        </div>
        <table border="1" class="customers">
            <tr>
                <th>Exam ID</th>
                <th>Exam Name</th>
                <th>Department Name</th>
                <th>Course</th>
                <th>Subject</th>
                <th>Date of Exam</th>
                <th>Q Paper File</th>
                <th>Generate Q Paper</th>
                <th>Upload Q Paper</th>
                <th></th>
                <th>Q Paper STATUS</th>

            </tr>
            <?php
            $res = mysqli_query($mycon, "select * from `tb_examdate`  where `department`='$deptname'");
            while ($rs = mysqli_fetch_array($res)) {
                echo "
                <form method='post' enctype='multipart/form-data'>
                <tr>
                <td><input name='exm_id' type='hidden' value='$rs[exam_id]'></td>
                <td>$rs[exam_name]</td>
                <td>$rs[department]</td>
                <td>$rs[course]</td>
                <td>$rs[subject]</td>
                <td>$rs[exam_date]</td>
                <td>$rs[qp_file]</td>
                <td><a href='qp_genrate.php?exam_id=$rs[exam_id]&subjectN=$rs[subject]&courseN=$rs[course]&examN=$rs[exam_name]&examD=$rs[exam_date]'>Click</a></td>
                <td><input type='file' name='filepick' id='pdf' accept='application/pdf'></td>
                <td><input type ='submit' value= 'upload' name='upload_pdf'></td>
                <td>$rs[status]</td>

                </tr>
                </form>";
            }
            ?>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
    </center>
</body>

</html>

<?php
include('MainFooter.html');
?>

<?php

if (isset($_POST["upload_pdf"])) {
    $folder_path = 'QP_Bank/';

    $filename = basename($_FILES['filepick']['name']);
    $newname = $folder_path . $filename;

    $FileType = pathinfo($newname, PATHINFO_EXTENSION);

    if ($FileType == "pdf") {
        if (move_uploaded_file($_FILES['filepick']['tmp_name'], $newname)) {

            $exam_id = $_POST['exm_id'];


            $filesql = "UPDATE  `tb_examdate` SET `qp_file` ='$filename',`status`='qp uploaded' WHERE `exam_id`='$exam_id'";

            echo $filesql;

            $fileresult = mysqli_query($mycon, $filesql);

            if (isset($fileresult)) {
                echo "<script>alert('File Uploaded')</script>";
                echo "<script>window.location.href='HOD_ExamDates.php';</script>";
            } else {
                echo "<script>alert('Something went Wrong')</script>";
            }
        } else {
            echo "<script>alert('Upload Failed')</script>";
        }
    } else {
        echo "<script>alert(Q Paper must be uploaded in PDF format)</script>";
    }
}

?>