<?php
include('dbConnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View HOD</title>
    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>



</head>

<body>

    <?php
    include('Header_Admin.html');
    ?>

    <center>
        <table border="1" class="customers">
            <tr>
                <th>Department Name</th>
                <th>HOD</th>
                <th>Assigned DATE</th>
                <th>CONTACT</th>
                <br />
                <br />
                <br />
            </tr>
            <?php
            $res = mysqli_query($mycon, "  select * from `tb_hod` ");
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr><td>$rs[depart_name]</td><td>$rs[name]</td><td>$rs[created_on]</td><td>$rs[contact]</td></tr>";
            }
            ?>
        </table>
    </center>

</body>

</html>

<?php
include("mainfooter.html")
?>