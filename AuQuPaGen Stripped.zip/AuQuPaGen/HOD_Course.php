<?php
include('dbConnection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dept Courses</title>
    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>
    <?php
    include('Header_HOD.html');
    ?>


</body>

</html>


<html>

<body>
    <center>
        <div>
            <h2 style="background-color: wheat; color: while;">View Course</h2>
        </div>
        <table border="1" class="customers">
            <tr>
                <th>Department</th>
                <th>Course</th>
                <th>HOD</th>
                <th>CREATED On</th>
                <th>Subjects</th>

                <br />
                <br />
                <br />
            </tr>
            <?php

            $hodname = $_SESSION['hod_name'];
            $res = mysqli_query($mycon, "SELECT * FROM `tb_course` c, `tb_hod`h WHERE c.`department`=h.`depart_name` AND `name`='$hodname'");
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr><td>$rs[department]</td><td>$rs[coursename]</td><td>$rs[name]</td><td>$rs[created_on]</td><td><a href='HOD_Subjects.php?courseName=$rs[coursename]&dept=$rs[department]'>View</a></td></tr>";
            }
            ?>
        </table>
        <br>
        <br>
    </center>


</body>

</html>
<?php
include('MainFooter.html');
?>