<?php
include('dbConnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD Department</title>
</head>

<body>

    <?php
    include('Header_Admin.html');
    ?>

    <center>

        <!-- <form>
            <br>
            <br>
            <br>
            <input type="text" placeholder="Department name" name="dept_name"><br><br>
            <input type="submit" value="Add Department" name="add_btn">

        </form> -->




        <!-- ................................................................... -->

        <br>
        <br>
        <br>
        <div class="col-lg-6 mt-lg-0 mt-5" data-aos="zoom-in">
            <!-- form grid -->
            <div class="register-top1">
                <form action="#" method="get" class="register-wthree">
                    <div class="form-group">
                        <!-- <div class="row"> -->
                        <div class="col-md-6">
                            <label>
                                Department name
                            </label>
                            <input class="form-control" type="text" placeholder="Department name" name="dept_name" required="TRUE">
                        </div>

                        <!-- </div> -->
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <button type="submit" name="add_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add Department</button>
                        </div>
                    </div>
                </form>
            </div>
            <!--  //form grid ends here -->
        </div>

        <!-- ................................................................... -->


    </center>

</body>

</html>
<?php
if (isset($_REQUEST['add_btn'])) {

    $dept = $_REQUEST['dept_name'];
    $date = date("d/m/Y");


    $qry = "insert into `tb_department` (`name`,`created_on`) values ('$dept','$date')";

    // echo $qry;

    $res = mysqli_query($mycon, "SELECT COUNT(*) AS cnt FROM `tb_department` WHERE `name`='$dept'");

    $rs = mysqli_fetch_array($res);

    if ($rs['cnt'] > 0) {
        echo "<script>alert('DepartMent Already Exists')</script>";
        echo "<script>window.location.href='Admin_AddDepartment.php';</script>";
    } else {
        mysqli_query($mycon, $qry);
        echo "<script>alert('Added New DepartMent')</script>";
        echo "<script>window.location.href='AdminHome.php';</script>";
    }
}
?>
<?php
include("mainfooter.html")
?>