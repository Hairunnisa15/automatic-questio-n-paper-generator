<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "db_qpaper_generator";

// Create connection
$mycon = new mysqli($servername, $username, $password, $db);

// Check connection
if ($mycon->connect_error) {
  die("Connection failed: " . $mycon->connect_error);
}
// echo "Connected successfully";
