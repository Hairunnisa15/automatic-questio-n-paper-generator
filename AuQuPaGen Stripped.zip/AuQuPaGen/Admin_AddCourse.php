<?php
include('dbConnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COURSES</title>
    <style>
        .customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        .customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .customers tr:hover {
            background-color: #ddd;
        }

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>
    <?php
    include('Header_Admin.html');
    ?>
    <center>
        <div>
            <h2 style="background-color: wheat; color: while;">Add Course</h2>
        </div>
        <div class="col-md-6">
            <form>
                <br>
                <br>
                <br>
                <input class="form-control" type="text" placeholder="Course Name" name="course_name"><br><br>
                <select class="form-control" name="deptname">
                    <option>....Choose Department....</option>
                    <?php
                    $res = mysqli_query($mycon, "SELECT * from `tb_department`");
                    while ($rs = mysqli_fetch_array($res)) {
                        echo "<option >" . $rs['name'] . "</option>";
                    }
                    ?>
                </select><br><br>

                <br>
                <br>

                <!-- <input type="submit" value="Add Course" name="add_btn"> -->

                <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="submit" name="add_btn" class="btn btn-w3_pvt btn-block w-100 font-weight-bold text-uppercase bg-theme1">Add Course</button>
                    </div>
                </div>
            </form>
            <br>
            <br>
            <br>
        </div>
    </center>

</body>

</html>
<?php
if (isset($_REQUEST['add_btn'])) {

    $name = $_REQUEST['course_name'];
    $department = $_REQUEST['deptname'];

    $date = date("d/m/Y");

    $qry = "INSERT INTO `tb_course` (`coursename`,`department`,`created_on`) VALUES('$name','$department','$date')";

    $res2 = mysqli_query($mycon, "SELECT COUNT(*) AS cnt FROM `tb_course` WHERE `coursename`='$name' AND `department`='$department' ");

    $rs2 = mysqli_fetch_array($res2);

    if ($rs2['cnt'] > 0) {
        echo "<script>alert('Course Already Assigned')</script>";
        echo "<script>window.location.href='Admin_AddCourse.php';</script>";
    } else {
        mysqli_query($mycon, $qry);
        echo "<script>alert('Added New Course')</script>";
        echo "<script>window.location.href='Admin_AddCourse.php';</script>";
    }
}
?>

<html>

<body>
    <center>
        <div>
            <h2 style="background-color: wheat; color: while;">View Course</h2>
        </div>
        <table border="1" class="customers">
            <tr>
                <th>Department</th>
                <th>Course</th>
                <th>HOD</th>
                <th>CREATED On</th>
                <th>Subjects</th>

                <br />
                <br />
                <br />
            </tr>
            <?php
            $res = mysqli_query($mycon, "SELECT * FROM `tb_course` c, `tb_hod`h WHERE c.`department`=h.`depart_name`");
            while ($rs = mysqli_fetch_array($res)) {
                echo "<tr><td>$rs[department]</td><td>$rs[coursename]</td><td>$rs[name]</td><td>$rs[created_on]</td></tr>";
            }
            ?>
        </table>
        <br>
        <br>
    </center>


</body>

</html>

<?php
include("mainfooter.html")
?>